create trigger T_CART
  before insert
  on SHOPCART
  for each row
  when (new.cartid is null)
begin
 select seq_cart.nextval into:new.cartid from dual;
end;
/

