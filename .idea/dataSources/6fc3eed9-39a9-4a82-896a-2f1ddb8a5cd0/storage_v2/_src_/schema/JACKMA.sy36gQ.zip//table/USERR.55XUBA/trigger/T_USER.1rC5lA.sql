create trigger T_USER
  before insert
  on USERR
  for each row
  when (new.userid is null)
begin
 select seq_user.nextval into:new.userid from dual;
end;
/

