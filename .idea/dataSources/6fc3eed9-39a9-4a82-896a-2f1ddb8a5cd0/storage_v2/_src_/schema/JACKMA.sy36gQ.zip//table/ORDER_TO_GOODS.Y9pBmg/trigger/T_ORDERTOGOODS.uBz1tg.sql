create trigger T_ORDERTOGOODS
  before insert
  on ORDER_TO_GOODS
  for each row
  when (new.otgid is null)
begin
 select seq_ordertogoods.nextval into:new.otgid from dual;
end;
/

