create trigger T_ORDER
  before insert
  on ORDERSS
  for each row
  when (new.ordersid is null)
begin
 select seq_order.nextval into:new.ordersid from dual;
end;
/

