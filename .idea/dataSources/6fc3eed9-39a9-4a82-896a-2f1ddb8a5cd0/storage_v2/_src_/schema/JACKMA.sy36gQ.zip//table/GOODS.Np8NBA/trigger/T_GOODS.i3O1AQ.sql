create trigger T_GOODS
  before insert
  on GOODS
  for each row
  when (new.GOODSID is null)
begin
  select SEQ_GOODS.nextval into:new.GOODSID from dual;
end;
/

